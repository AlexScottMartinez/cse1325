#include "gate.h"
#include "and.h"
#include "or.h"
#include <vector> 
#include <iostream>

int main(){

    std::cout<< "A B C D Q\n";
    std::cout<< "= = = = =\n";
    std::vector<bool> answer = {};
    
    for(int i=0; i<5; i++) {
        
    }
}
